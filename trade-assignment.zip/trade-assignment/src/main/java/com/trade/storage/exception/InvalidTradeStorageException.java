package com.trade.storage.exception;

public class InvalidTradeStorageException extends RuntimeException {

    /**
	 * 
	 */
	private static final long serialVersionUID = -6659444143508399166L;
	
	private final String id;

    public InvalidTradeStorageException(final String id) {
        super("Invalid Trade: " + id);
        this.id = id;
    }

    public String getId() {
        return id;
    }
}
