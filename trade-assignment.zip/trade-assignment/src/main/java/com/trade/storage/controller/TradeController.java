package com.trade.storage.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.trade.storage.exception.InvalidTradeStorageException;
import com.trade.storage.model.Trade;
import com.trade.storage.service.TradeService;

@RestController
public class TradeController {
	
	@Autowired
	private TradeService tradeService;

	@PostMapping("/trade")
	public ResponseEntity<String> tradeValidateStore(@RequestBody Trade trade) {
		if (tradeService.isValid(trade)) {
			tradeService.persist(trade);
		} else {
			throw new InvalidTradeStorageException(trade.getTradeId() + "  Trade Id is not found");
		}
		return ResponseEntity.status(HttpStatus.OK).build();
	}

	@GetMapping("/trade")
	public List<Trade> findAllTrades() {
		return tradeService.findAll();
	}
}
