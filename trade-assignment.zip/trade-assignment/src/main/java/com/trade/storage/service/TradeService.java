package com.trade.storage.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.trade.storage.dao.TradeRepository;
import com.trade.storage.model.Trade;

@Service
public class TradeService {

	private static final Logger log = LoggerFactory.getLogger(TradeService.class);

	@Autowired
	private TradeRepository tradeRepository;

	public boolean isValid(Trade trade) {
		if (validateMaturityDate(trade.getMaturityDate())) {
			Optional<Trade> exsitingTrade = tradeRepository.findById(trade.getTradeId());
			if (exsitingTrade.isPresent()) {
				return validateVersion(trade.getVersion(), exsitingTrade.get().getVersion());
			} else {
				return true;
			}
		}
		return false;
	}

	// validation 1 During transmission if the
	// lower version is being received by the store it will reject the trade and
	// throw an exception.
	private boolean validateVersion(Integer newTradeVersion, Integer oldTradeVersion) {
		if (newTradeVersion >= oldTradeVersion) {
			return true;
		}
		return false;
	}

	// Store should not allow the trade which has less maturity date then today
	// date
	private boolean validateMaturityDate(LocalDate maturityDate) {
		return maturityDate.isBefore(LocalDate.now()) ? false : true;
	}

	public void persist(Trade trade) {
		trade.setCreatedDate(LocalDate.now());
		tradeRepository.save(trade);
	}

	public List<Trade> findAll() {
		return tradeRepository.findAll();
	}

	public void updateExpiryFlagOfTrade() {
		tradeRepository.findAll().stream().forEach(trade -> {
			if (!validateMaturityDate(trade.getMaturityDate())) {
				trade.setExpiredFlag("Y");
				log.info("Trade which needs to be updated : {}", trade);
				tradeRepository.save(trade);
			}
		});
	}

}
