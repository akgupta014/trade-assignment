package com.trade.storage.controller;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.trade.storage.exception.InvalidTradeStorageException;
import com.trade.storage.model.Trade;

@ExtendWith(SpringExtension.class)
@SpringBootTest
public class TradeControllerTest {

	@Test
	public void contextLoads() {
	}

	@Autowired
	private TradeController tradeController;

	@Test
	public void testTradeStoreWhenInvalidTrade() {
		try {
			tradeController.tradeValidateStore(createTrade("T1",1,LocalDate.now()));
		} catch (Exception e) {
			Assertions.assertNotNull(e);
		}
	}

	@Test
	public void testTradeStoreWhenMaturityDatePast() {
		try {
			LocalDate localDate = getLocalDate(2021, 05, 21);
			tradeController.tradeValidateStore(createTrade("T2", 1, localDate));
		}catch (InvalidTradeStorageException ie) {
			Assertions.assertEquals("Invalid Trade: T2  Trade Id is not found", ie.getMessage());
		}
	}

	@Test
	public void testTradeStoreWhenOldVersion() {
		// step-1 create trade
		ResponseEntity<?> responseEntity = tradeController.tradeValidateStore(createTrade("T1",2,LocalDate.now()));
		Assertions.assertEquals(ResponseEntity.status(HttpStatus.OK).build(),responseEntity);
		List<Trade> tradeList =tradeController.findAllTrades();
		Assertions.assertEquals(2, tradeList.size());
		Assertions.assertEquals("T2",tradeList.get(0).getTradeId());
		Assertions.assertEquals(1,tradeList.get(0).getVersion());
		Assertions.assertEquals("B1",tradeList.get(0).getBookId());

		//step-2 create trade with old version
		try {
			tradeController.tradeValidateStore(createTrade("T1", 1, LocalDate.now()));
		} catch (InvalidTradeStorageException e){
			System.out.println(e.getId());
			System.out.println(e.getMessage());
		}
		List<Trade> tradeList1 =tradeController.findAllTrades();
		Assertions.assertEquals(2, tradeList1.size());
		Assertions.assertEquals("T2",tradeList1.get(0).getTradeId());
		Assertions.assertEquals(1,tradeList1.get(0).getVersion());
		Assertions.assertEquals("B1",tradeList.get(0).getBookId());
	}

	@Test
	public void testTradeStoreWhenSameVersionTrade(){
		ResponseEntity<?> responseEntity = tradeController.tradeValidateStore(createTrade("T1",2,LocalDate.now()));
		Assertions.assertEquals(ResponseEntity.status(HttpStatus.OK).build(),responseEntity);
		List<Trade> tradeList =tradeController.findAllTrades();
		Assertions.assertEquals(2, tradeList.size());
		Assertions.assertEquals("T2",tradeList.get(0).getTradeId());
		Assertions.assertEquals(1,tradeList.get(0).getVersion());
		Assertions.assertEquals("B1",tradeList.get(0).getBookId());

		//step-2 create trade with same version
		Trade trade2 = createTrade("T1",2,LocalDate.now());
		trade2.setBookId("B1");
		ResponseEntity<?> responseEntity2 = tradeController.tradeValidateStore(trade2);
		Assertions.assertEquals(ResponseEntity.status(HttpStatus.OK).build(),responseEntity2);
		List<Trade> tradeList2 =tradeController.findAllTrades();
		Assertions.assertEquals(2, tradeList2.size());
		Assertions.assertEquals("T2",tradeList2.get(0).getTradeId());
		Assertions.assertEquals(1,tradeList2.get(0).getVersion());
		Assertions.assertEquals("B1",tradeList2.get(0).getBookId());

		//step-2 create trade with new version
		Trade trade3 = createTrade("T1",2,LocalDate.now());
		trade3.setBookId("B1");
		ResponseEntity<?> responseEntity3 = tradeController.tradeValidateStore(trade3);
		Assertions.assertEquals(ResponseEntity.status(HttpStatus.OK).build(),responseEntity3);
		List<Trade> tradeList3 =tradeController.findAllTrades();
		Assertions.assertEquals(2, tradeList3.size());
		Assertions.assertEquals("T2",tradeList3.get(0).getTradeId());
		Assertions.assertEquals(1,tradeList3.get(0).getVersion());
		Assertions.assertEquals("B1",tradeList3.get(0).getBookId());

	}
	
	private Trade createTrade(String tradeId,int version,LocalDate  maturityDate){
		Trade trade = new Trade();
		trade.setTradeId(tradeId);
		trade.setBookId("B1");
		trade.setVersion(version);
		trade.setCounterPartyId(tradeId+"Cpty");
		trade.setMaturityDate(maturityDate);
		trade.setExpiredFlag("Y");
		return trade;
	}

	private LocalDate getLocalDate(int year,int month, int day){
		LocalDate localDate = LocalDate.of(year,month,day);
		return localDate;
	}




}
